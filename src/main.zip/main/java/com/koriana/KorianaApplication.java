package com.koriana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KorianaApplication {

	public static void main(String[] args) {
		SpringApplication.run(KorianaApplication.class, args);
	}

}
