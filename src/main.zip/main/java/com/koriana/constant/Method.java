package com.koriana.constant;

public enum Method {
	GET, POST, PUT, PATCH, DELETE
}
